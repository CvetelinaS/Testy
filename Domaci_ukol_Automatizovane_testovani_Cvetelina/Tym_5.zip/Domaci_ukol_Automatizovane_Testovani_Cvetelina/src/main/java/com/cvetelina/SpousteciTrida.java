package com.company;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        System.out.println("Zdravim, pozemstani! Zavedte me ke svemu vudci");

    }
}